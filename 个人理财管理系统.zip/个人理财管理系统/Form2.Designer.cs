﻿namespace 个人理财管理系统
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            menuStrip1 = new MenuStrip();
            系统管理ToolStripMenuItem = new ToolStripMenuItem();
            退出ToolStripMenuItem = new ToolStripMenuItem();
            注销ToolStripMenuItem = new ToolStripMenuItem();
            收支管理ToolStripMenuItem = new ToolStripMenuItem();
            添加收支ToolStripMenuItem = new ToolStripMenuItem();
            修改收支ToolStripMenuItem = new ToolStripMenuItem();
            toolStripSeparator2 = new ToolStripSeparator();
            统计查询ToolStripMenuItem = new ToolStripMenuItem();
            基本资料ToolStripMenuItem = new ToolStripMenuItem();
            收支类别管理ToolStripMenuItem = new ToolStripMenuItem();
            收支项目管理ToolStripMenuItem = new ToolStripMenuItem();
            toolStripSeparator3 = new ToolStripSeparator();
            用户管理ToolStripMenuItem = new ToolStripMenuItem();
            帮助ToolStripMenuItem = new ToolStripMenuItem();
            menuStrip1.SuspendLayout();
            SuspendLayout();
            // 
            // menuStrip1
            // 
            menuStrip1.ImageScalingSize = new Size(24, 24);
            menuStrip1.Items.AddRange(new ToolStripItem[] { 系统管理ToolStripMenuItem, 收支管理ToolStripMenuItem, 基本资料ToolStripMenuItem, 帮助ToolStripMenuItem });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Size = new Size(997, 32);
            menuStrip1.TabIndex = 4;
            menuStrip1.Text = "menuStrip1";
            // 
            // 系统管理ToolStripMenuItem
            // 
            系统管理ToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { 退出ToolStripMenuItem, 注销ToolStripMenuItem });
            系统管理ToolStripMenuItem.Name = "系统管理ToolStripMenuItem";
            系统管理ToolStripMenuItem.Size = new Size(98, 28);
            系统管理ToolStripMenuItem.Text = "系统管理";
            系统管理ToolStripMenuItem.Click += 系统管理ToolStripMenuItem_Click;
            // 
            // 退出ToolStripMenuItem
            // 
            退出ToolStripMenuItem.Name = "退出ToolStripMenuItem";
            退出ToolStripMenuItem.Size = new Size(228, 34);
            退出ToolStripMenuItem.Text = "退出(E)";
            退出ToolStripMenuItem.Click += 退出ToolStripMenuItem_Click;
            // 
            // 注销ToolStripMenuItem
            // 
            注销ToolStripMenuItem.Name = "注销ToolStripMenuItem";
            注销ToolStripMenuItem.Size = new Size(228, 34);
            注销ToolStripMenuItem.Text = "注销(Z)  Alt+Z";
            注销ToolStripMenuItem.Click += 注销ToolStripMenuItem_Click;
            // 
            // 收支管理ToolStripMenuItem
            // 
            收支管理ToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { 添加收支ToolStripMenuItem, 修改收支ToolStripMenuItem, toolStripSeparator2, 统计查询ToolStripMenuItem });
            收支管理ToolStripMenuItem.Name = "收支管理ToolStripMenuItem";
            收支管理ToolStripMenuItem.Size = new Size(98, 28);
            收支管理ToolStripMenuItem.Text = "收支管理";
            收支管理ToolStripMenuItem.Click += 收支管理ToolStripMenuItem_Click;
            // 
            // 添加收支ToolStripMenuItem
            // 
            添加收支ToolStripMenuItem.Name = "添加收支ToolStripMenuItem";
            添加收支ToolStripMenuItem.Size = new Size(270, 34);
            添加收支ToolStripMenuItem.Text = "添加收支";
            添加收支ToolStripMenuItem.Click += 添加收支ToolStripMenuItem_Click;
            // 
            // 修改收支ToolStripMenuItem
            // 
            修改收支ToolStripMenuItem.Name = "修改收支ToolStripMenuItem";
            修改收支ToolStripMenuItem.Size = new Size(270, 34);
            修改收支ToolStripMenuItem.Text = "修改收支";
            修改收支ToolStripMenuItem.Click += 修改收支ToolStripMenuItem_Click;
            // 
            // toolStripSeparator2
            // 
            toolStripSeparator2.BackColor = SystemColors.ActiveCaptionText;
            toolStripSeparator2.Name = "toolStripSeparator2";
            toolStripSeparator2.Size = new Size(267, 6);
            // 
            // 统计查询ToolStripMenuItem
            // 
            统计查询ToolStripMenuItem.Name = "统计查询ToolStripMenuItem";
            统计查询ToolStripMenuItem.Size = new Size(270, 34);
            统计查询ToolStripMenuItem.Text = "统计查询";
            // 
            // 基本资料ToolStripMenuItem
            // 
            基本资料ToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { 收支类别管理ToolStripMenuItem, 收支项目管理ToolStripMenuItem, toolStripSeparator3, 用户管理ToolStripMenuItem });
            基本资料ToolStripMenuItem.Name = "基本资料ToolStripMenuItem";
            基本资料ToolStripMenuItem.Size = new Size(98, 28);
            基本资料ToolStripMenuItem.Text = "基本资料";
            // 
            // 收支类别管理ToolStripMenuItem
            // 
            收支类别管理ToolStripMenuItem.Name = "收支类别管理ToolStripMenuItem";
            收支类别管理ToolStripMenuItem.Size = new Size(270, 34);
            收支类别管理ToolStripMenuItem.Text = "收支类别管理";
            收支类别管理ToolStripMenuItem.Click += 收支类别管理ToolStripMenuItem_Click;
            // 
            // 收支项目管理ToolStripMenuItem
            // 
            收支项目管理ToolStripMenuItem.Name = "收支项目管理ToolStripMenuItem";
            收支项目管理ToolStripMenuItem.Size = new Size(270, 34);
            收支项目管理ToolStripMenuItem.Text = "收支项目管理";
            // 
            // toolStripSeparator3
            // 
            toolStripSeparator3.Name = "toolStripSeparator3";
            toolStripSeparator3.Size = new Size(267, 6);
            // 
            // 用户管理ToolStripMenuItem
            // 
            用户管理ToolStripMenuItem.Name = "用户管理ToolStripMenuItem";
            用户管理ToolStripMenuItem.Size = new Size(270, 34);
            用户管理ToolStripMenuItem.Text = "用户管理";
            // 
            // 帮助ToolStripMenuItem
            // 
            帮助ToolStripMenuItem.Name = "帮助ToolStripMenuItem";
            帮助ToolStripMenuItem.Size = new Size(62, 28);
            帮助ToolStripMenuItem.Text = "帮助";
            // 
            // Form2
            // 
            AutoScaleDimensions = new SizeF(11F, 24F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(997, 553);
            Controls.Add(menuStrip1);
            MainMenuStrip = menuStrip1;
            Name = "Form2";
            Text = "Form2";
            Load += Form2_Load;
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private MenuStrip menuStrip1;
        private ToolStripMenuItem 系统管理ToolStripMenuItem;
        private ToolStripMenuItem 退出ToolStripMenuItem;
        private ToolStripMenuItem 注销ToolStripMenuItem;
        private ToolStripMenuItem 收支管理ToolStripMenuItem;
        private ToolStripMenuItem 基本资料ToolStripMenuItem;
        private ToolStripMenuItem 帮助ToolStripMenuItem;
        private ToolStripMenuItem 添加收支ToolStripMenuItem;
        private ToolStripMenuItem 修改收支ToolStripMenuItem;
        private ToolStripMenuItem 统计查询ToolStripMenuItem;
        private ToolStripMenuItem 收支类别管理ToolStripMenuItem;
        private ToolStripMenuItem 收支项目管理ToolStripMenuItem;
        private ToolStripMenuItem 用户管理ToolStripMenuItem;
        private ToolStripSeparator toolStripSeparator2;
        private ToolStripSeparator toolStripSeparator3;
    }
}